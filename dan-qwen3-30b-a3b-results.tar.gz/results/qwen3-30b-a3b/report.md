# GPU validation report

Status: PASS at 32,768-token native context
Date / operator / rental image: 2026-09-05 UTC / Codex / rented GPU pod (Ubuntu 24.04 x86-64)
DAN revision / llama.cpp revision: c5b3bfd84ed8a8aa995623ab059d381714f6425b / 95ef7fc16054e63b427a3ef00188e055ef7586d8
GPU name / driver / CUDA compiler: NVIDIA A40 / 570.195.03 / CUDA 12.8.93
Total VRAM / free VRAM before load / observed peak VRAM: 46,068 MiB / 45,498 MiB / 21,227 MiB during the successful DAN run
Model ID / role / family: dan-main / main / Qwen3-30B-A3B
GGUF filename(s) / source / SHA256 / quantization / total bytes: Qwen3-30B-A3B-Q4_K_M.gguf / official Qwen Hugging Face GGUF repository / 0d003f6662faee786ed5da3e31b29c978de5ae5d275c8794c606a7f3c01aa8f5 / Q4_K_M / 18,556,685,824 bytes
Configured context / token cap / offloaded layers: 32,768 / direct 256, DAN -1 / 999 to CUDA0
Direct load success or failure / load time / generated tokens per second: success at 4,096 and 32,768 context / 4,726.57 ms and 4,191.91 ms / 147.76 and 164.87 eval tokens/s respectively
DAN runtime ready time / CUDA offload evidence: 5,500.4 ms / CUDA runtime reported ARCHS=860; direct 4,096 run observed 18,535 MiB VRAM; successful DAN 32,768 run observed 21,227 MiB VRAM and 93% GPU utilization. Provider received --runtime-device CUDA0 and --gpu-layers 999.
DAN responses received (out of 10) / process exit codes: 10 / coordinator 0, provider 0
Per-request latency: 2897.1, 2049.9, 4437.6, 6122.1, 4720.6, 4025.9, 3053.8, 4391.5, 3648.5, 3099.5 ms; 3844.7 ms average. See dan-gpu-32768/results.json and dan-gpu-32768/coordinator.log.
Answer quality / truncation / context carryover observations: All ten responses were nonempty and answered their prompts. Qwen3 generated visible default thinking traces before final answers. No truncation was observed at 32,768 context; the persistent session carries prior context by design.
Crashes / inference errors / OOM / retries and configuration changes: Initial 4,096-context DAN run returned 8 responses, then stopped on request 9 because Qwen3's thinking traces filled the context; this was not OOM. The failed evidence remains in dan-gpu/. Native 32,768 context was direct-tested, then the unchanged driver passed ten responses. llama.cpp emitted the existing non-fatal control-token and duplicate --n-predict warnings.
Artifacts: direct.log, direct-vram.csv, direct-32768.log, direct-32768-vram.csv, dan-gpu/, dan-gpu-32768/, models.gpu.conf, qwen3-30b-a3b-q4_k_m.sha256
Conclusion: pass. Official Qwen3-30B-A3B Q4_K_M ran entirely on CUDA0 on the A40 and completed the real persistent DAN workflow. GPU-memory monitoring establishes execution beyond self-reported metadata. The serious candidate requires a larger session context than the earlier 7B baseline when default Qwen3 thinking mode is used.

A CPU smoke run or self-reported CUDA metadata is not a GPU acceptance pass.
